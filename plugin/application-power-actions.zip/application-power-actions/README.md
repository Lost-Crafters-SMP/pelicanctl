# Application Power Actions Plugin

This plugin adds power action endpoints to the Application API, allowing application tokens (admin API keys) to send power commands (start, stop, restart, kill) to servers.

## Features

- Adds `POST /api/application/servers/{server}/power` endpoint
- Supports all power actions: start, stop, restart, kill
- Uses the same backend logic as the Client API
- Automatically documented in Scramble API documentation

## Requirements

- Application tokens need `AdminAcl::WRITE` permission on the `'server'` resource
- Token permissions JSON should include: `"server": 2` or `"server": 3` (READ+WRITE)
- Root admins with `TYPE_ACCOUNT` tokens get automatic bypass (full access)

## Installation

1. Place this plugin in the `lostcrafters-plugins` directory
2. The plugin will be automatically discovered and registered
3. No additional configuration needed

## Usage

Send a POST request to `/api/application/servers/{server}/power` with:

```json
{
  "signal": "start"
}
```

Valid signals: `start`, `stop`, `restart`, `kill`

## API Documentation

The endpoint is automatically documented in Scramble at `/docs/api/application` under the "Server" group.
