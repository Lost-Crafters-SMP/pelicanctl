<?php

use Illuminate\Support\Facades\Route;
use LostCrafters\ApplicationPowerActions\Http\Controllers\PowerController;

Route::post('/servers/{server:id}/power', [PowerController::class, 'power']);
Route::get('/servers/{server:id}/health', [PowerController::class, 'health']);
