<?php

namespace LostCrafters\ApplicationPowerActions;

use Filament\Contracts\Plugin;
use Filament\Panel;

class ApplicationPowerActions implements Plugin
{
    public function getId(): string
    {
        return 'application-power-actions';
    }

    public function register(Panel $panel): void
    {
        // No resources, pages, or widgets to register
    }

    public function boot(Panel $panel): void
    {
        // No boot-time logic needed
    }
}
