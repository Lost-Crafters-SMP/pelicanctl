<?php

namespace LostCrafters\ApplicationPowerActions\Http\Controllers;

use App\Enums\ContainerStatus;
use App\Facades\Activity;
use App\Http\Controllers\Api\Application\ApplicationApiController;
use App\Models\ActivityLog;
use App\Models\Server;
use App\Repositories\Daemon\DaemonServerRepository;
use Carbon\Carbon;
use Dedoc\Scramble\Attributes\Group;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use LostCrafters\ApplicationPowerActions\Http\Requests\GetHealthRequest;
use LostCrafters\ApplicationPowerActions\Http\Requests\SendPowerRequest;

#[Group('Server', weight: 4)]
class PowerController extends ApplicationApiController
{
    /**
     * PowerController constructor.
     */
    public function __construct(private DaemonServerRepository $repository)
    {
        parent::__construct();
    }

    /**
     * Send power action
     *
     * Send a power action to a server.
     *
     * @throws ConnectionException
     */
    public function power(SendPowerRequest $request, Server $server): Response
    {
        $this->repository->setServer($server)->power(
            $request->input('signal')
        );

        Activity::event(strtolower("server:power.{$request->input('signal')}"))->log();

        return $this->returnNoContent();
    }

    /**
     * Get server health
     *
     * Get the current health status of a server, including container status
     * and optional crash detection within a time window.
     *
     * @return JsonResponse
     */
    public function health(GetHealthRequest $request, Server $server): JsonResponse
    {
        $status = $server->retrieveStatus();
        $healthy = $status === ContainerStatus::Running;
        $checkedAt = Carbon::now();

        $crashDetails = null;
        $crashed = false;

        // Check for crashes if time window is provided
        if ($request->has('since') || $request->has('window')) {
            $since = null;

            if ($request->has('since')) {
                $since = Carbon::parse($request->input('since'));
            } elseif ($request->has('window')) {
                $since = $checkedAt->copy()->subMinutes((int) $request->input('window'));
            }

            if ($since) {
                $crashLog = ActivityLog::where('event', 'server:crashed')
                    ->whereHas('subjects', function ($query) use ($server) {
                        $query->where('subject_type', Server::class)
                            ->where('subject_id', $server->id);
                    })
                    ->where('timestamp', '>=', $since)
                    ->orderBy('timestamp', 'desc')
                    ->first();

                if ($crashLog) {
                    $crashed = true;
                    $crashDetails = [
                        'timestamp' => $crashLog->timestamp->toIso8601String(),
                        'exit_code' => $crashLog->properties->get('exit_code'),
                        'oom_killed' => $crashLog->properties->get('oomkilled', false),
                    ];
                }
            }
        }

        return response()->json([
            'server' => [
                'id' => $server->id,
                'uuid' => $server->uuid,
                'uuid_short' => $server->uuid_short,
                'name' => $server->name,
                'external_id' => $server->external_id,
                'server_status' => $server->status?->value,
                'node_id' => $server->node_id,
            ],
            'container' => [
                'status' => $status->value,
                'healthy' => $healthy,
            ],
            'crashed' => $crashed,
            'crash_details' => $crashDetails,
            'checked_at' => $checkedAt->toIso8601String(),
        ]);
    }
}
