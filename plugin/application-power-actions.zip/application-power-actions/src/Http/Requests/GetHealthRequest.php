<?php

namespace LostCrafters\ApplicationPowerActions\Http\Requests;

use App\Http\Requests\Api\Application\Servers\GetServerRequest;

class GetHealthRequest extends GetServerRequest
{
    /**
     * Rules to validate this request against.
     */
    public function rules(): array
    {
        return [
            'since' => 'nullable|date',
            'window' => 'nullable|integer|min:1|max:1440', // Max 24 hours in minutes
        ];
    }
}
