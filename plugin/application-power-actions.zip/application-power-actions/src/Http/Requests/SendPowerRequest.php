<?php

namespace LostCrafters\ApplicationPowerActions\Http\Requests;

use App\Http\Requests\Api\Application\Servers\ServerWriteRequest;

class SendPowerRequest extends ServerWriteRequest
{
    /**
     * Rules to validate this request against.
     */
    public function rules(): array
    {
        return [
            'signal' => 'required|string|in:start,stop,restart,kill',
        ];
    }
}
