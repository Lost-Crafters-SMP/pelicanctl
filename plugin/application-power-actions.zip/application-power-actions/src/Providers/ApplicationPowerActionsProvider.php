<?php

namespace LostCrafters\ApplicationPowerActions\Providers;

use Illuminate\Support\ServiceProvider;

class ApplicationPowerActionsProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        //
    }
}
