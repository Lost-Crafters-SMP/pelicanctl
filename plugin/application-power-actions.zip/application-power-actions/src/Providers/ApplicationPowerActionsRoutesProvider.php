<?php

namespace LostCrafters\ApplicationPowerActions\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Route;

class ApplicationPowerActionsRoutesProvider extends RouteServiceProvider
{
    public function boot(): void
    {
        $this->routes(function () {
            Route::middleware(['api', 'application-api', 'throttle:api.application'])
                ->prefix('/api/application')
                ->scopeBindings()
                ->group(plugin_path('application-power-actions', 'routes/api-application.php'));
        });
    }
}
